"use strict"; 

// var imageCache = [];

var makeImage = function(infile, inreader, phistart, phiend, thetastart, thetaend) {

  var iready = false;
  var ifile = infile;
  var ireader = inreader;
  var ifname = ifile.name;
  var isize = ifile.size;
  var imaxval = null;
  var ihres = null;
  var ivres = null;
  var ihist = [0,0,0,0,0,0,0,0,0,0,0];
  var iphistart = phistart;
  var iphiend = phiend;
  var ithetastart = thetastart;
  var ithetaend = thetaend;
  var i_lines = [];
  var i_line_count = 0;
  var i_cur_line = 3; 
  var i_rawtext = null;
  var i_imgarray = null;
  var i_tokens = [];
  var i_cur_token = -1;
  var i_token_error = false;


  var break_raw_text = function(txt) {
      var txt_len = txt.length; 
      var i;

      while ( txt.length > 0 ) {
        if ((i = txt.indexOf("\n")) != -1) {
          var current_len = txt.length;
          i_lines[i_line_count] = txt.substr(0, i);
          txt = txt.substr(i+1, current_len);
          i_line_count += 1;
        }
        else {
          txt = "";
        }
      }
      console.log("    line count = " + i_line_count.toString());
      return;
  };


  var clampint = function(v, minv, maxv, maxval) {

    var newv = Math.round(v * maxval);
    if (newv < minv) newv = minv;
    if (newv > maxv) newv = maxv;

    return newv;
  };


  var add_hist = function(v) {

    var i = Math.round( v * 10 );
    ihist[i] += 1;
    return v;
  };

  var print_hist = function() {

    console.log( "print_hist " + ifname ); 
    for (var i = 0; i < ihist.length; i++) {
      console.log("hist " + i.toString() + " = " + ihist[i].toString());
    }
  }; 

  var get_token = function() {

      if (i_tokens.length > 0) {
        return i_tokens.shift();
      } else {
        i_cur_line += 1;
        if (i_cur_line < i_line_count) {
          i_tokens = i_lines[i_cur_line].split(' ');
          return i_tokens.shift();
        } else {
          i_token_error = true;
          return "0";
        }
      }
      console.log("*** get_token error ***");
  }


  var build_image_array = function() {
    var i, j;
    
    for (i = 0; i < ihres; i++) {
      for (j = 0; j < ivres; j++) {
        if (i_token_error == false) {
          i_imgarray[i][j] = add_hist(parseFloat(get_token()) / imaxval); 
        } else {
          return(false);
        }
      }
    }
    if (i_token_error == true) { return(false); }
    else { return(true); }
  };

  var verify_and_process_image = function() {

    var tokens;

    if (i_line_count > 3 && i_lines[0] == "P2") {

      tokens = i_lines[1].split(' ');
      ihres = parseInt(tokens[0]);
      ivres = parseInt(tokens[1]);
      imaxval = parseFloat(i_lines[2]);

      console.log("    hres = " + ihres.toString());
      console.log("    vres = " + ivres.toString());
      console.log("    maxval = " + imaxval.toString());
      i_imgarray = new Array(ihres);
      for (var i = 0; i < ihres; i++) {
        i_imgarray[i] = new Array(ivres);
      }
      // i_imgarray.fill(0.0);
      iready = build_image_array();

    } else {
      iready = false;
      console.log("    file is not type P2");
    }
    print_hist();
    return iready;    
  };

  console.log( "makeImage: " + ifname + " " + self.toString());

  return {

    load_and_verify: function() {

      console.log("    load_and_verify");

      ireader.onload = function (e) {
        i_rawtext = ireader.result;
        console.log("    size of rawtext = " + i_rawtext.length.toString());
        break_raw_text(i_rawtext);
        verify_and_process_image();
      }
      ireader.readAsText(ifile);
      return;
    },

    is_ready: function() {
      return iready;
    },  

    get_pixel: function(inx, iny) {

      var nx = Math.round(clampint(inx, 0, ihres-1, ihres));
      var ny = Math.round(clampint(iny, 0, ivres-1, ivres));
      
      return i_imgarray[nx][ny];
    },

    get_disp: function(x, y, sizex, sizey) {
      let a = avg_pixel(this.get_pixel(x, y, sizex, sizey));
      this.add_hist(a);
      return(a);
    },

    decrement: function() {
    }

  };

};

console.log("makeImage defined");




function read_pgm_files() {

    var infilelen = imageInput.files.length;

    console.log("in file len = " + infilelen.toString());

    for (var i = 0; i < infilelen; i++) {
      var file = imageInput.files[i];
      var reader = new FileReader();
      var img = makeImage(file, reader);

      img.load_and_verify();
      imageCache.push(img);
      console.log("imageCache len = " + imageCache.length.toString());
    }

      // var file = imageInput.files[0];
      // var reader = new FileReader();
      // console.log("readfile = " + file.name);

/*
    reader.onload = function(e) {
      mytxt = reader.result;
      lines = [];
      lines_count = 0;
      BreakFileIntoLines();
      PrintCounts();
    }
    reader.readAsText(file);
*/
}


function clear_image_cache() {
    imageCache = [];
    console.log("imageCache cleared");
} 
